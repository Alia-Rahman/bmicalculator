package com.example.bmicalculator;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class OwnerDetailsActivity extends AppCompatActivity {

    private TextView githubLinkTextView;
    private Button backButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_owner_details);

        githubLinkTextView = findViewById(R.id.githubLinkTextView);
        backButton = findViewById(R.id.backButton);

        githubLinkTextView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openGitHubProfile();
            }
        });

        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
    }

    private void openGitHubProfile() {
        String githubUrl = "https://alia-rahman.github.io/bmicalculator/";
        Uri uri = Uri.parse(githubUrl);
        Intent intent = new Intent(Intent.ACTION_VIEW, uri);
        startActivity(intent);
    }
}
