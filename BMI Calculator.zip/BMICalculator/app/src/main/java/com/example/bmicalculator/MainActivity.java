package com.example.bmicalculator;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private EditText heightEditText, weightEditText;
    private TextView bmiCategoryTextView, bmiRangeTextView, healthRiskTextView;
    private Button calculateButton, aboutOwnerButton;

    private SharedPreferences sharedPreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        heightEditText = findViewById(R.id.heightEditText);
        weightEditText = findViewById(R.id.weightEditText);
        bmiCategoryTextView = findViewById(R.id.bmiCategoryTextView);
        bmiRangeTextView = findViewById(R.id.bmiRangeTextView);
        healthRiskTextView = findViewById(R.id.healthRiskTextView);
        calculateButton = findViewById(R.id.calculateButton);
        aboutOwnerButton = findViewById(R.id.aboutOwnerButton);

        sharedPreferences = getSharedPreferences("MyPrefs", Context.MODE_PRIVATE);

        String savedHeight = sharedPreferences.getString("height", "");
        String savedWeight = sharedPreferences.getString("weight", "");

        heightEditText.setText(savedHeight);
        weightEditText.setText(savedWeight);

        calculateButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                calculateBMI();
            }
        });

        aboutOwnerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openOwnerDetailsActivity();
            }
        });
    }

    private void calculateBMI() {
        String heightString = heightEditText.getText().toString().trim();
        String weightString = weightEditText.getText().toString().trim();

        if (heightString.isEmpty() || weightString.isEmpty()) {
            Toast.makeText(this, "Please enter your height and weight", Toast.LENGTH_SHORT).show();
            return;
        }

        double heightInCm = Double.parseDouble(heightString);  // Convert height to centimeters
        double weight = Double.parseDouble(weightString);

        double heightInM = heightInCm / 100.0;  // Convert height to meters

        double bmi = weight / (heightInM * heightInM);

        String bmiCategory = getBMICategory(bmi);
        String bmiRange = getBMIRange(bmiCategory);
        String healthRisk = getHealthRisk(bmiCategory);

        bmiCategoryTextView.setText("BMI Category: " + bmiCategory);
        bmiRangeTextView.setText("BMI Range: " + bmiRange);
        healthRiskTextView.setText("Health Risk: " + healthRisk);

        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString("height", heightString);
        editor.putString("weight", weightString);
        editor.apply();
    }

    private String getBMICategory(double bmi) {
        if (bmi <= 18.4) {
            return "Underweight";
        } else if (bmi <= 24.9) {
            return "Normal weight";
        } else if (bmi <= 29.9) {
            return "Overweight";
        } else if (bmi <= 34.9) {
            return "Moderately obese";
        } else if (bmi <= 39.9) {
            return "Severely obese";
        } else {
            return "Very severely obese";
        }
    }

    private String getBMIRange(String bmiCategory) {
        switch (bmiCategory) {
            case "Underweight":
                return "18.4 and below (kg/m²)";
            case "Normal weight":
                return "18.5 - 24.9 (kg/m²)";
            case "Overweight":
                return "25 - 29.9 (kg/m²)";
            case "Moderately obese":
                return "30 - 34.9 (kg/m²)";
            case "Severely obese":
                return "35 - 39.9 (kg/m²)";
            case "Very severely obese":
                return "40 and above (kg/m²)";
            default:
                return "";
        }
    }

    private String getHealthRisk(String bmiCategory) {
        switch (bmiCategory) {
            case "Underweight":
                return "Malnutrition risk";
            case "Normal weight":
                return "Low risk";
            case "Overweight":
                return "Enhanced risk";
            case "Moderately obese":
                return "Medium risk";
            case "Severely obese":
                return "High risk";
            case "Very severely obese":
                return "Very high risk";
            default:
                return "";
        }
    }

    private void openOwnerDetailsActivity() {
        Intent intent = new Intent(this, OwnerDetailsActivity.class);
        startActivity(intent);
    }
}
